package com.acmetravel;

import java.io.Serializable;

public class Pagination implements Serializable {

	private static final long serialVersionUID = 7137532379202195752L;
	private int limit;
	private int offset;
	private int count;

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
}
