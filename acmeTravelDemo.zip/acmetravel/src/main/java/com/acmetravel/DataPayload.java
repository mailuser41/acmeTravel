package com.acmetravel;

import java.io.Serializable;
import java.util.List;

public class DataPayload implements Serializable {

	private static final long serialVersionUID = 7383860259118777166L;

	private String airlineName;

	private List<Destination> destinations;

	private Pagination pagination;

	public String getAirlineName() {
		return airlineName;
	}

	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	public List<Destination> getDestinations() {
		return destinations;
	}

	public void setDestinations(List<Destination> destinations) {
		this.destinations = destinations;
	}

	public Pagination getPagination() {
		return pagination;
	}

	public void setPagination(Pagination pagination) {
		this.pagination = pagination;
	}

}
