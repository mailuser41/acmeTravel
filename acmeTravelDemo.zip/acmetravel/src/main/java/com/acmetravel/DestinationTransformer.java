package com.acmetravel;

import java.util.Arrays;
import java.util.List;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DestinationTransformer extends AbstractMessageTransformer {

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {

		int limit = message.getInvocationProperty("limit");
		int offset = message.getInvocationProperty("offset");
		String airlineName = message.getInvocationProperty("airlineName");

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);

		try {

			List<Destination> destinations = Arrays
					.asList(objectMapper.readValue(message.getPayload().toString(), Destination[].class));

			Pagination pagination = new Pagination();
			pagination.setCount(destinations.size());
			pagination.setLimit(limit);
			pagination.setOffset(offset);

			DataPayload dataPayload = new DataPayload();
			dataPayload.setDestinations(destinations);
			dataPayload.setPagination(pagination);
			dataPayload.setAirlineName(airlineName);

			return objectMapper.writeValueAsString(dataPayload);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}
}